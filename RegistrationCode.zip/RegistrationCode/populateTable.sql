declare @GeneratedCode varchar(6)
declare @count int

set @count = 1
while @count <= 1000
begin
	EXEC DERMSL_Test..pGenerateMemberCode @GeneratedCode OUTPUT
	insert into MEMBERCODES(MemberCode,MEMBERSignupDataID)
	select @GeneratedCode, NULL
end